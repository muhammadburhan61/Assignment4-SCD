# quiz_data.py

quiz_data = [
    {
        "question": "What is the capital of Pakistan?",
        "choices": ["Karachi", "Islamabad", "Lahore", "Quetta"],
        "answer": "Islamabad"
    },
    {
        "question": "Which language is used for Android development?",
        "choices": ["Swift", "Kotlin", "JavaScript", "Python"],
        "answer": "Kotlin"
    },
    {
        "question": "Which planet is known as the Red Planet?",
        "choices": ["Earth", "Mars", "Venus", "Saturn"],
        "answer": "Mars"
    }
]
